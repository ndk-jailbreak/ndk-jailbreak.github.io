var currSong = '';
function checkMusic(){
if (isplaying === 1) {
document.getElementById('playPause').classList.remove("zeek-buttonplay");
document.getElementById('playPause').classList.add("zeek-buttonpause");
}else{
document.getElementById('playPause').classList.remove("zeek-buttonpause");
document.getElementById('playPause').classList.add("zeek-buttonplay");}
if(title === "(null)"){
document.getElementById('title').innerHTML = 'Chưa phát';
document.getElementById('artist').innerHTML = 'Không có nghệ sĩ';
document.getElementById('minTitle').innerHTML = 'Say hello to the future';
if(muP === 1){
document.getElementById('musCont').style.display = 'none';}
}else{
if(muP === 1){
document.getElementById('musCont').style.display = 'block';}
if(currSong !== title){
currSong = title;
animTitle(title, artist);}
document.getElementById('minTitle').innerHTML = title;
if (checkOverflow(document.getElementById('minTitle')) === true){
document.getElementById('minTitle').classList.add("marquee");
}else{
document.getElementById('minTitle').classList.remove("marquee");}
if (checkOverflow(document.getElementById('title')) === true){
document.getElementById('title').classList.add("marquee");
}else{
document.getElementById('title').classList.remove("marquee");}
}
if(album === "(null)"){
document.getElementById('musicArt').src = 'Scripts/Js/Mus.js';
}else{
var xhr = new XMLHttpRequest();
xhr.open('HEAD', "file:///var/mobile/Documents/Artwork.jpg", false);
xhr.send();
if (xhr.status === "404") {
document.getElementById('musicArt').src = 'Scripts/Js/Mus.js';
}else{
document.getElementById('musicArt').src = "file:///var/mobile/Documents/Artwork.jpg?" + (new Date()).getTime();}}
}
function checkOverflow(el) {
var curOverflow = el.style.overflow;
if ( !curOverflow || curOverflow === "visible" ){
el.style.overflow = "hidden"; }
var isOverflowing = el.clientWidth < el.scrollWidth || el.clientHeight < el.scrollHeight;
el.style.overflow = curOverflow;
return isOverflowing;}
function playPause() {
if ( document.getElementById('playPause').classList.contains("zeek-buttonplay")){ 
document.getElementById('playPause').classList.remove("zeek-buttonplay");
document.getElementById('playPause').classList.add("zeek-buttonpause");
}else{		document.getElementById('playPause').classList.remove("zeek-buttonpause");
document.getElementById('playPause').classList.add("zeek-buttonplay");}
window.location = 'xeninfo:playpause';}
function next() {
document.getElementById('next').style.transform = 'translateY(-50%) scale(0.5,0.5)';
window.location = 'xeninfo:nexttrack';
setTimeout(function (){
document.getElementById('next').style.transform = 'translateY(-50%) scale(1,1)';}, 200);}		
function prev() {
document.getElementById('prev').style.transform = 'translateY(-50%) scale(0.5,0.5)';
window.location = 'xeninfo:prevtrack';
setTimeout(function (){
document.getElementById('prev').style.transform = 'translateY(-50%) scale(1,1)';}, 200);}
function animTitle(str, str2){
document.getElementById('infoCont').style.opacity = 0;	document.getElementById('infoCont').classList.add('movetop');
setTimeout(function (){
document.getElementById('infoCont').style.opacity = 1;
document.getElementById('infoCont').classList.remove('movetop');
document.getElementById('title').innerHTML = str;
if(str2 === "(null)"){
document.getElementById('artist').innerHTML = '';
}else{
document.getElementById('artist').innerHTML = str2;}}, 500);}