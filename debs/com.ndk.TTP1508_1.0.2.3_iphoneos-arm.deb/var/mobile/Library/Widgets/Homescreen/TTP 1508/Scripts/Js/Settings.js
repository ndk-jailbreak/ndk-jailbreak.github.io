function checkSettings(){
// on off
if(!config.music){
document.getElementById('MuCont').style.display = 'none';
}
if(!config.HumiWind){
document.getElementById('HumiBg').style.display = 'none';
document.getElementById('WindBg').style.display = 'none';
}

// color
document.documentElement.style.setProperty('--infoCl', config.infoCl);
document.documentElement.style.setProperty('--teCl', config.teCl);
document.documentElement.style.setProperty('--lightCl', config.lightCl);

// blur & bor
document.documentElement.style.setProperty('--wallShadow', config.wallShadow + 'px');

document.documentElement.style.setProperty('--muBr', config.muBr + 'px');
document.documentElement.style.setProperty('--HuWiBr', config.HuWiBr + 'px');

document.documentElement.style.setProperty('--muBgBl', config.muBgBl + 'px');
document.documentElement.style.setProperty('--wallBl', config.wallBl + 'px');

// images
document.getElementById("Shadow").src="Scripts/Js/Shadow.js";
document.getElementById('Overlay').src = 'Scripts/Images/' + config.Overlay + '.png';

// location
document.documentElement.style.setProperty('--huwiY', config.huwiY + '%');

// font size
document.documentElement.style.setProperty('--tbFontS', config.tbFontS + 'px');
}

// height & width
document.documentElement.style.setProperty('--shadowY', config.shadowY + '%');
document.documentElement.style.setProperty('--MuW', config.MuW + '%');